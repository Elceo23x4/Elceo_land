# ELCEO SVG-07 Rev-B Layer Map — Reference-Aligned Gauge + Meter System

This revision specifically corrects the semi-circle gauge language to follow the supplied ELCEO dashboard reference more closely.

## Correction focus
- Multi-colour sectioned semi-circle gauges, not plain single arcs.
- Outer amber micro-tick arc and segmented scale language.
- Thick active bands broken into multiple sections with deliberate gaps.
- Thin bright inner value arc beneath the thick band.
- Dormant amber remainder band on the right side where applicable.
- Nested center score rings/voids for future numeric content; no text is baked into the SVG.
- Freshness-style side energy chunk included as a separate editable polygon.

## Files
- `elceo-svg-07-revb-semicircle-gauges-reference-aligned.svg`
- `elceo-svg-07-revb-horizontal-meters.svg`
- `elceo-svg-07-revb-mini-score-rings.svg`
- `elceo-svg-07-revb-review-sheet.svg`
- `elceo-svg-07-revb-composite-preview.svg`

## Key IDs
### Confidence gauge
- `gauge_confidence_multisection`
- `gauge_confidence_multisection_outer_amber_track`
- `gauge_confidence_multisection_main_colored_section_1..4`
- `gauge_confidence_multisection_bright_inner_value_arc`
- `gauge_confidence_multisection_dormant_remainder_band`
- `gauge_confidence_multisection_value_end_diamond`

### Contradiction gauge
- `gauge_contradiction_multisection`
- `gauge_contradiction_multisection_main_colored_section_1..2`
- `gauge_contradiction_multisection_bright_inner_value_arc`
- `gauge_contradiction_multisection_value_end_diamond`

### Freshness gauge
- `gauge_freshness_multisection`
- `gauge_freshness_multisection_main_colored_section_1..4`
- `gauge_freshness_multisection_side_chunk`

### Zone strength gauge
- `gauge_zone_strength_multisection`
- `gauge_zone_strength_multisection_main_colored_section_1..4`

## Integration note
The numeric percentages/labels should still be rendered by React later. These SVGs provide only the gauge frame, arcs, markers, and state language.
